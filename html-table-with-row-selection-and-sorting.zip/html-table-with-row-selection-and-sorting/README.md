# Html table with row selection and sorting

A Pen created on CodePen.io. Original URL: [https://codepen.io/Avdhoot21/pen/ExLXmeQ](https://codepen.io/Avdhoot21/pen/ExLXmeQ).

